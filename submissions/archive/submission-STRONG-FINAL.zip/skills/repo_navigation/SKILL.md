---
name: repo_navigation
description: Efficient repository navigation and investigation patterns for SWE tasks.
---

# Repository Navigation

Use targeted repository exploration.

## First-pass commands

Prefer:

pwd
git status --short
find . -maxdepth 2 -type f | sort
rg "relevant_symbol_or_text" .

Avoid recursively printing the entire repository.

## Finding implementation

Use ripgrep to locate:

- class names
- function names
- exception messages
- configuration keys
- API endpoints
- test names
- user-visible error messages

## Understanding relationships

When a symbol is known:

- use get_code_neighbors for callers and callees;
- use search_similar_code for related implementations;
- use get_code_subgraph when several symbols form one execution path.

## Reading files

Use read_file with targeted line ranges whenever possible.

Do not repeatedly read the same large file.

## Testing

Start with the narrowest relevant test.

Example:

pytest tests/path/to/test_file.py -q

Then expand testing only when useful.

## Patch hygiene

Before submitting:

git status --short
git diff --stat
git diff

Remove temporary files created during investigation.

Do not modify evaluator-generated pytest.ini or conftest.py unless explicitly
required by the task.
