# Repository Navigation Skill

Use this skill to navigate before editing.

## Fast path
1. git status --short
2. git grep -n for the strongest exact anchor
3. read_file around the definition
4. find the nearest relevant test and callers
5. patch the smallest production code path
6. verify and submit

## Graph path
Use graph tools when the issue involves a symbol with multiple callers, values passed across modules, wrapper/delegation layers, or ambiguous ownership of behavior.

Do not use graph tools merely because they exist. Each call must resolve a specific uncertainty.

## Search fallback
If exact search fails, try symbol/name, error message, test name, filename/module, then a short semantic phrase with search_similar_code.

Stop when the root cause is sufficiently evidenced.
