---
name: repo-repair-playbook
description: Repair priors by task family for Python library issues. Load only at MEDIUM or LOW confidence or after a failed test, then open exactly one reference file for the matching family.
---
# Repo repair playbook

Open ONE file with load_skill_resource, file_path references/FAMILY.md. Each file has LOOK (subsystems and symbols to inspect before editing), PITFALL (what a first fix usually misses) and TEST (test pattern).

Families: dependency-callable, types-annotations, compat-versions, parse-serialize, http-request, render-format, state-cache-lifecycle, contract-errors-validation, async-sync, multi-file-propagation.

Always: anchor on exact symbols, read before editing, make the smallest change, fix every sibling path, run the narrowest test.
