# parse-serialize
LOOK: the encoder/decoder/builder producing the wrong output and the options that shape it (exclude_unset/none/defaults, by_alias, include/exclude, mode); for malformed input the tokenizer, regex or splitter.
PITFALL: encode and decode are pairs; the schema generator must mirror what runtime accepts and returns.
TEST: assert exact output for edge inputs: empty, None, nested, unicode, duplicate keys.
