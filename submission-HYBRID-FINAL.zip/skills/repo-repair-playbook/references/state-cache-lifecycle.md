# state-cache-lifecycle
LOOK: where state lives (module globals, class attributes, mutable defaults, lru_cache or dict caches) and how keys are built; setup and teardown order (exit stack, finally, contextlib).
PITFALL: keys missing an input; no reset where state mutates; cleanup skipped on exceptions or run in the wrong order.
TEST: call twice with different inputs and in different order; assert no leakage and the teardown side effects.
