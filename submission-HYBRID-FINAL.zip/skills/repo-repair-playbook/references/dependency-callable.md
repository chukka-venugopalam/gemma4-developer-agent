# dependency-callable
LOOK: where a callable is classified (function, coroutine, generator, async generator, class, partial, object with __call__), where its signature is read (inspect.signature, __wrapped__, partial.func/args/keywords), then the dependency model/builder and its cache key.
PITFALL: classification feeds execution (await vs threadpool vs context manager) and the cache key; fixing one classifier leaves the others wrong.
TEST: nearest dependency test file; tiny app using the new callable form, one request, assert status and value.
