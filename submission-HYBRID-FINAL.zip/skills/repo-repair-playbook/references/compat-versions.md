# compat-versions
LOOK: the central compat module and every version guard or try/except ImportError for the feature (grep the guard name); find the active branch with python -c 'import X; print(X.__version__)'.
PITFALL: fixing only the inactive branch; changing a shim's public signature; importing an optional dependency at module level.
TEST: nearest test on the installed versions; start from the traceback's first repo frame.
