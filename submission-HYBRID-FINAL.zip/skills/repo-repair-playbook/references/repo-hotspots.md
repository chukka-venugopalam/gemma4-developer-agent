# Repository family hotspots
These are search-priority hints derived from the released training-task distribution. They are not deterministic mappings.

FASTAPI: dependency modeling/execution, compatibility layers, routing, OpenAPI generation, applications, params.
Common high-frequency modules in training included:
- fastapi/dependencies/models.py
- fastapi/dependencies/utils.py
- fastapi/_compat/v2.py
- fastapi/_compat.py
- fastapi/routing.py
- fastapi/applications.py
- fastapi/openapi/utils.py
- fastapi/params.py

RICH: console/cells/markdown/table/ansi/file_proxy/traceback/export and Unicode-width data are recurring areas.

REQUESTS: models.py, _types.py, status_codes.py are recurring areas.

HTTPX: treat as unfamiliar; rely on exact anchors, tests, and local structure rather than a hardcoded hotspot list.

Use these only to prioritize the first search when an issue is weakly anchored. Confirm the actual target before editing.
