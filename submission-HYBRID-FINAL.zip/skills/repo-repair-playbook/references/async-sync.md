# async-sync
LOOK: the dispatch decision (coroutine, generator or blocking callable: await vs run in threadpool) and the twin implementations (sync/async clients, __enter__/__aenter__, iter/aiter).
PITFALL: fixing one twin; wrappers (partial, decorators) hiding coroutine-ness; blocking the event loop.
TEST: run both variants in the async test style already used by nearby tests.
