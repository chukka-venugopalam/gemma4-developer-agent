# render-format
LOOK: the measure, wrap, render pipeline (character cell width, line splitting, justify/overflow), style and markup parsing/escaping, terminal and environment detection (width, color system, is_terminal).
PITFALL: width fixes belong in measuring AND rendering; zero-width and combining characters; trailing spaces and newlines; ANSI codes inside expected strings.
TEST: render to a string with fixed width, force_terminal and color_system; compare exact output.
