# types-annotations
LOOK: annotation resolution (get_type_hints, get_origin/get_args, ForwardRef evaluated with the function's globals), Annotated metadata unpacking, the helper that decides scalar vs sequence vs model.
PITFALL: None and default handling; the same annotation must resolve identically for params, body, response model and schema output.
TEST: parametrize plain, Optional, Union, X | None, Annotated and string forms; assert the resolved type or behavior.
