# http-request
LOOK: request preparation (URL, headers, body, auth), the send/redirect loop (what is kept or stripped: auth, cookies, method, body), proxy and environment resolution, response decoding (encoding, iter_content, json).
PITFALL: sync and async clients, Session and top-level helpers drifting apart; case-insensitive header lookups; bytes vs str.
TEST: assert on the prepared request (URL string, headers) or use the repo's mock transport or local server; no live network.
