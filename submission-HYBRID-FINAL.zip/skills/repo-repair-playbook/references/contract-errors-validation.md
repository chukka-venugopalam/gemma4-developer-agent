# contract-errors-validation
LOOK: the guard closest to the input entry, exception class and message construction, and the public signature (add keywords with defaults; keep positional order).
PITFALL: tests assert type, message and status exactly as the issue words them; breaking previously accepted inputs; missing a sibling entry point that shares the signature.
TEST: pytest.raises(Type, match=issue text) plus one old-behavior case.
