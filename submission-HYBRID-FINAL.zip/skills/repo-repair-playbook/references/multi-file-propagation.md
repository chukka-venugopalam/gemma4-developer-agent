# multi-file-propagation
LOOK: follow the value from the public entry through each forwarder to its consumer: signature, stored attribute, internal builder, final use; grep the parameter or function name to list siblings.
PITFALL: threading a new option through one layer only; app-level vs router-level, client vs session duplicates; forgetting to export a new public name.
TEST: call through each public entry with the new option and assert the effect.
