---
name: repo-repair-playbook
description: Evidence-first repair priors and repository navigation heuristics for SWE tasks.
---
# Repository Repair Playbook

Use this skill to choose what to inspect, not to assume the answer.

Open at most ONE family reference when confidence is MEDIUM/LOW or after a failed test.
Use load_skill_resource with the matching file under references/.

Families:
- dependency-callable
- types-annotations
- compat-versions
- parse-serialize
- http-request
- render-format
- state-cache-lifecycle
- contract-errors-validation
- async-sync
- multi-file-propagation
- repo-hotspots

Always verify the prior against actual source and tests.
Never use a family name as a file-mapping shortcut.
